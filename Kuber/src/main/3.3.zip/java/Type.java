public enum Type {
    WORKER,
    CLIENT,
    UNKNOWN
}
